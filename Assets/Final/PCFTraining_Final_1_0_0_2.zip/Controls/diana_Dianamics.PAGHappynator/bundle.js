/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PAGHappynator/Components/IconToggle.tsx":
/*!*************************************************!*\
  !*** ./PAGHappynator/Components/IconToggle.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.IconToggle = void 0;\n/* eslint-disable react/display-name */\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Icon_1 = __webpack_require__(/*! @fluentui/react/lib/Icon */ \"@fluentui/react/lib/Icon\");\nvar Label_1 = __webpack_require__(/*! @fluentui/react/lib/Label */ \"@fluentui/react/lib/Icon\");\nvar Styling_1 = __webpack_require__(/*! @fluentui/react/lib/Styling */ \"@fluentui/react/lib/Icon\");\nvar iconContainerClass = (0, Styling_1.mergeStyles)({\n  width: \"100px\",\n  height: \"40px\",\n  display: \"inline-flex\",\n  flexWrap: \"nowrap\",\n  justifyContent: \"flex-start\",\n  alignItems: \"baseline\",\n  cursor: \"pointer\",\n  border: \"1px solid transparent\"\n}, {\n  selectors: {\n    \":hover\": {\n      borderColor: \"lightGray\"\n    },\n    i: {\n      fontSize: \"20px\",\n      marginTop: \"3px\"\n    },\n    label: {\n      cursor: \"pointer\"\n    }\n  }\n});\nexports.IconToggle = React.memo(function (_a) {\n  var iconOn = _a.iconOn,\n    iconOff = _a.iconOff,\n    colorOn = _a.colorOn,\n    colorOff = _a.colorOff,\n    labelOn = _a.labelOn,\n    labelOff = _a.labelOff,\n    value = _a.value,\n    onChange = _a.onChange;\n  var changeValue = React.useCallback(function () {\n    onChange && onChange(!value);\n  }, [value]);\n  return React.createElement(\"div\", {\n    className: iconContainerClass,\n    onClick: changeValue\n  }, React.createElement(\"div\", {\n    style: {\n      width: \"30px\"\n    }\n  }, React.createElement(Icon_1.Icon, {\n    iconName: value ? iconOn : iconOff,\n    style: {\n      color: value ? colorOn : colorOff\n    }\n  })), React.createElement(Label_1.Label, null, value === true ? labelOn : labelOff));\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGHappynator/Components/IconToggle.tsx?");

/***/ }),

/***/ "./PAGHappynator/Customizer/CellEditorOverrides.tsx":
/*!**********************************************************!*\
  !*** ./PAGHappynator/Customizer/CellEditorOverrides.tsx ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nvar _a;\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.cellEditorOverrides = void 0;\nvar React = __webpack_require__(/*! react */ \"react\");\nvar IconToggle_1 = __webpack_require__(/*! ../Components/IconToggle */ \"./PAGHappynator/Components/IconToggle.tsx\");\nexports.cellEditorOverrides = (_a = {}, _a[\"TwoOptions\"] = function (defaultProps, rendererParams) {\n  var column = rendererParams.colDefs[rendererParams.columnIndex];\n  if (column.name === \"diana_ishappy\") {\n    var value_1 = defaultProps.value;\n    // rendererParams.onCellValueChanged(!value); //autochange value on click\n    var onChange = function onChange() {\n      rendererParams.onCellValueChanged(!value_1);\n      rendererParams.stopEditing(false);\n    };\n    return React.createElement(IconToggle_1.IconToggle, {\n      iconOn: \"Emoji2\",\n      iconOff: \"Sad\",\n      colorOn: \"green\",\n      colorOff: \"red\",\n      labelOn: column.customizerParams.labels.onText,\n      labelOff: column.customizerParams.labels.offText,\n      value: defaultProps.value === true,\n      onChange: onChange\n    });\n  }\n}, _a);\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGHappynator/Customizer/CellEditorOverrides.tsx?");

/***/ }),

/***/ "./PAGHappynator/Customizer/CellRendererOverrides.tsx":
/*!************************************************************!*\
  !*** ./PAGHappynator/Customizer/CellRendererOverrides.tsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nvar _a;\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.cellRendererOverrides = void 0;\n/* eslint-disable @typescript-eslint/no-unused-vars */\nvar React = __webpack_require__(/*! react */ \"react\");\nvar IconToggle_1 = __webpack_require__(/*! ../Components/IconToggle */ \"./PAGHappynator/Components/IconToggle.tsx\");\nexports.cellRendererOverrides = (_a = {}, _a[\"TwoOptions\"] = function (props, rendererParams) {\n  var column = rendererParams.colDefs[rendererParams.columnIndex];\n  if (column.name === \"diana_ishappy\") {\n    var onCellClicked = function onCellClicked() {\n      if (props.startEditing) props.startEditing(!props.value);\n    };\n    return React.createElement(IconToggle_1.IconToggle, {\n      iconOn: \"Emoji2\",\n      iconOff: \"Sad\",\n      colorOn: \"green\",\n      colorOff: \"red\",\n      labelOn: column.customizerParams.labels.onText,\n      labelOff: column.customizerParams.labels.offText,\n      value: props.value === true,\n      onChange: onCellClicked\n    });\n  }\n}, _a);\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGHappynator/Customizer/CellRendererOverrides.tsx?");

/***/ }),

/***/ "./PAGHappynator/index.ts":
/*!********************************!*\
  !*** ./PAGHappynator/index.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.PAGHappynator = void 0;\nvar CellEditorOverrides_1 = __webpack_require__(/*! ./Customizer/CellEditorOverrides */ \"./PAGHappynator/Customizer/CellEditorOverrides.tsx\");\nvar CellRendererOverrides_1 = __webpack_require__(/*! ./Customizer/CellRendererOverrides */ \"./PAGHappynator/Customizer/CellRendererOverrides.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar PAGHappynator = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function PAGHappynator() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  PAGHappynator.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    var eventName = context.parameters.EventName.raw;\n    if (eventName) {\n      var paOneGridCustomizer = {\n        cellRendererOverrides: CellRendererOverrides_1.cellRendererOverrides,\n        cellEditorOverrides: CellEditorOverrides_1.cellEditorOverrides\n      };\n      context.factory.fireEvent(eventName, paOneGridCustomizer);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  PAGHappynator.prototype.updateView = function (context) {\n    return React.createElement(React.Fragment);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  PAGHappynator.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  PAGHappynator.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return PAGHappynator;\n}();\nexports.PAGHappynator = PAGHappynator;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGHappynator/index.ts?");

/***/ }),

/***/ "@fluentui/react/lib/Icon":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./PAGHappynator/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dianamics.PAGHappynator', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PAGHappynator);
} else {
	var Dianamics = Dianamics || {};
	Dianamics.PAGHappynator = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PAGHappynator;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}