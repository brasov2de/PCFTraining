/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./Happynator/Components/IconToggle.tsx":
/*!**********************************************!*\
  !*** ./Happynator/Components/IconToggle.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.IconToggle = void 0;\n/* eslint-disable react/display-name */\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Icon_1 = __webpack_require__(/*! @fluentui/react/lib/Icon */ \"@fluentui/react/lib/Icon\");\nvar Label_1 = __webpack_require__(/*! @fluentui/react/lib/Label */ \"@fluentui/react/lib/Icon\");\nvar Styling_1 = __webpack_require__(/*! @fluentui/react/lib/Styling */ \"@fluentui/react/lib/Icon\");\nvar iconContainerClass = (0, Styling_1.mergeStyles)({\n  width: \"100px\",\n  height: \"40px\",\n  display: \"inline-flex\",\n  flexWrap: \"nowrap\",\n  justifyContent: \"flex-start\",\n  alignItems: \"baseline\",\n  cursor: \"pointer\",\n  border: \"1px solid transparent\"\n}, {\n  selectors: {\n    \":hover\": {\n      borderColor: \"lightGray\"\n    },\n    i: {\n      fontSize: \"20px\",\n      marginTop: \"3px\"\n    },\n    label: {\n      cursor: \"pointer\"\n    }\n  }\n});\nexports.IconToggle = React.memo(function (_a) {\n  var iconOn = _a.iconOn,\n    iconOff = _a.iconOff,\n    colorOn = _a.colorOn,\n    colorOff = _a.colorOff,\n    labelOn = _a.labelOn,\n    labelOff = _a.labelOff,\n    value = _a.value,\n    onChange = _a.onChange;\n  var changeValue = React.useCallback(function () {\n    onChange(!value);\n  }, [value]);\n  return React.createElement(\"div\", {\n    className: iconContainerClass,\n    onClick: changeValue\n  }, React.createElement(\"div\", {\n    style: {\n      width: \"30px\"\n    }\n  }, React.createElement(Icon_1.Icon, {\n    iconName: value ? iconOn : iconOff,\n    style: {\n      color: value ? colorOn : colorOff\n    }\n  })), React.createElement(Label_1.Label, null, value === true ? labelOn : labelOff));\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Happynator/Components/IconToggle.tsx?");

/***/ }),

/***/ "./Happynator/index.ts":
/*!*****************************!*\
  !*** ./Happynator/index.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.Happynator = void 0;\nvar IconToggle_1 = __webpack_require__(/*! ./Components/IconToggle */ \"./Happynator/Components/IconToggle.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Happynator = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function Happynator() {\n    var _this = this;\n    this.onChange = function (value) {\n      _this.value = value;\n      _this.notifyOutputChanged();\n    };\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  Happynator.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  //icons: https://developer.microsoft.com/en-us/fluentui#/styles/web/icons\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  Happynator.prototype.updateView = function (context) {\n    var _a, _b, _c, _d, _e, _f, _g;\n    var options = (_a = context.parameters.sampleProperty.attributes) === null || _a === void 0 ? void 0 : _a.Options;\n    var props = {\n      colorOn: (_b = options === null || options === void 0 ? void 0 : options[1].Color) !== null && _b !== void 0 ? _b : \"green\",\n      colorOff: (_c = options === null || options === void 0 ? void 0 : options[0].Color) !== null && _c !== void 0 ? _c : \"red\",\n      labelOn: (_d = options === null || options === void 0 ? void 0 : options[1].Label) !== null && _d !== void 0 ? _d : \"Happy\",\n      labelOff: (_e = options === null || options === void 0 ? void 0 : options[0].Label) !== null && _e !== void 0 ? _e : \"Sad\",\n      iconOn: (_f = context.parameters.iconOn.raw) !== null && _f !== void 0 ? _f : \"Emoji2\",\n      iconOff: (_g = context.parameters.iconOff.raw) !== null && _g !== void 0 ? _g : \"Sad\",\n      value: context.parameters.sampleProperty.raw || false,\n      onChange: this.onChange.bind(this)\n    };\n    return React.createElement(IconToggle_1.IconToggle, props);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  Happynator.prototype.getOutputs = function () {\n    return {\n      sampleProperty: this.value\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  Happynator.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return Happynator;\n}();\nexports.Happynator = Happynator;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./Happynator/index.ts?");

/***/ }),

/***/ "@fluentui/react/lib/Icon":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./Happynator/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dianamics.Happynator', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Happynator);
} else {
	var Dianamics = Dianamics || {};
	Dianamics.Happynator = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.Happynator;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}