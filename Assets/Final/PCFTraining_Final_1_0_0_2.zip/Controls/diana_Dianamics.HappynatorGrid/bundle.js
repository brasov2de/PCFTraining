/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./HappynatorGrid/Components/IconToggle.tsx":
/*!**************************************************!*\
  !*** ./HappynatorGrid/Components/IconToggle.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.IconToggle = void 0;\n/* eslint-disable react/display-name */\nvar React = __webpack_require__(/*! react */ \"react\");\nvar Icon_1 = __webpack_require__(/*! @fluentui/react/lib/Icon */ \"@fluentui/react/lib/DetailsList\");\nvar Label_1 = __webpack_require__(/*! @fluentui/react/lib/Label */ \"@fluentui/react/lib/DetailsList\");\nvar Styling_1 = __webpack_require__(/*! @fluentui/react/lib/Styling */ \"@fluentui/react/lib/DetailsList\");\nvar iconContainerClass = (0, Styling_1.mergeStyles)({\n  width: \"100px\",\n  height: \"40px\",\n  display: \"inline-flex\",\n  flexWrap: \"nowrap\",\n  justifyContent: \"flex-start\",\n  alignItems: \"baseline\",\n  cursor: \"pointer\",\n  border: \"1px solid transparent\"\n}, {\n  selectors: {\n    \":hover\": {\n      borderColor: \"lightGray\"\n    },\n    i: {\n      fontSize: \"20px\",\n      marginTop: \"3px\"\n    },\n    label: {\n      cursor: \"pointer\"\n    }\n  }\n});\nexports.IconToggle = React.memo(function (_a) {\n  var iconOn = _a.iconOn,\n    iconOff = _a.iconOff,\n    colorOn = _a.colorOn,\n    colorOff = _a.colorOff,\n    labelOn = _a.labelOn,\n    labelOff = _a.labelOff,\n    value = _a.value,\n    onChange = _a.onChange;\n  var changeValue = React.useCallback(function () {\n    onChange && onChange(!value);\n  }, [value]);\n  return React.createElement(\"div\", {\n    className: iconContainerClass,\n    onClick: changeValue\n  }, React.createElement(\"div\", {\n    style: {\n      width: \"30px\"\n    }\n  }, React.createElement(Icon_1.Icon, {\n    iconName: value ? iconOn : iconOff,\n    style: {\n      color: value ? colorOn : colorOff\n    }\n  })), React.createElement(Label_1.Label, null, value === true ? labelOn : labelOff));\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./HappynatorGrid/Components/IconToggle.tsx?");

/***/ }),

/***/ "./HappynatorGrid/HappynatorGrid.tsx":
/*!*******************************************!*\
  !*** ./HappynatorGrid/HappynatorGrid.tsx ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

eval("\n\nvar __spreadArray = this && this.__spreadArray || function (to, from, pack) {\n  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {\n    if (ar || !(i in from)) {\n      if (!ar) ar = Array.prototype.slice.call(from, 0, i);\n      ar[i] = from[i];\n    }\n  }\n  return to.concat(ar || Array.prototype.slice.call(from));\n};\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.HappynatorGridComponent = void 0;\n/* eslint-disable react/display-name */\nvar React = __webpack_require__(/*! react */ \"react\");\nvar DetailsList_1 = __webpack_require__(/*! @fluentui/react/lib/DetailsList */ \"@fluentui/react/lib/DetailsList\");\nvar IconToggle_1 = __webpack_require__(/*! ./Components/IconToggle */ \"./HappynatorGrid/Components/IconToggle.tsx\");\nexports.HappynatorGridComponent = React.memo(function (_a) {\n  var dataset = _a.dataset,\n    isCanvas = _a.isCanvas;\n  var columns = dataset.columns.sort(function (column1, column2) {\n    return column1.order - column2.order;\n  }).map(function (column) {\n    var isHappyColumn = column.alias === 'happyProperty';\n    return {\n      key: column.name,\n      name: column.displayName,\n      fieldName: column.name,\n      minWidth: column.visualSizeFactor < 10 ? 100 : column.visualSizeFactor,\n      onRender: isHappyColumn ? function (item) {\n        return React.createElement(IconToggle_1.IconToggle, {\n          colorOn: 'green',\n          colorOff: 'red',\n          iconOn: 'Emoji2',\n          iconOff: 'Sad',\n          labelOn: 'Happy',\n          labelOff: 'Sad',\n          value: item.raw.getValue(column.name) == true || item.raw.getValue(column.name) == \"1\",\n          onChange: function onChange(value) {\n            var record = item.raw;\n            if (isCanvas) {\n              record.setValue(column.name, {\n                Id: value === true ? true : false\n              });\n            } else {\n              record.setValue(column.name, value);\n            }\n            record.save();\n          }\n        });\n      } : undefined\n    };\n  });\n  var _b = React.useState([]),\n    items = _b[0],\n    setItems = _b[1];\n  React.useEffect(function () {\n    var newItems = dataset.sortedRecordIds.map(function (id) {\n      var record = dataset.records[id];\n      var attributes = dataset.columns.map(function (column) {\n        var _a;\n        return _a = {}, _a[column.name] = record.getFormattedValue(column.name), _a;\n      });\n      return Object.assign.apply(Object, __spreadArray(__spreadArray([{}], attributes, false), [{\n        key: record.getRecordId(),\n        raw: record\n      }], false));\n    });\n    setItems(newItems);\n  }, [dataset]);\n  return React.createElement(DetailsList_1.DetailsList, {\n    items: items,\n    columns: columns\n  });\n});\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./HappynatorGrid/HappynatorGrid.tsx?");

/***/ }),

/***/ "./HappynatorGrid/index.ts":
/*!*********************************!*\
  !*** ./HappynatorGrid/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.HappynatorGrid = void 0;\nvar HappynatorGrid_1 = __webpack_require__(/*! ./HappynatorGrid */ \"./HappynatorGrid/HappynatorGrid.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar HappynatorGrid = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function HappynatorGrid() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  HappynatorGrid.prototype.init = function (context, notifyOutputChanged, state) {\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  HappynatorGrid.prototype.updateView = function (context) {\n    var props = {\n      dataset: context.parameters.dataset,\n      isCanvas: context.parameters.isCanvas.raw === \"true\"\n    };\n    return React.createElement(HappynatorGrid_1.HappynatorGridComponent, props);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  HappynatorGrid.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  HappynatorGrid.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return HappynatorGrid;\n}();\nexports.HappynatorGrid = HappynatorGrid;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./HappynatorGrid/index.ts?");

/***/ }),

/***/ "@fluentui/react/lib/DetailsList":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./HappynatorGrid/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Dianamics.HappynatorGrid', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HappynatorGrid);
} else {
	var Dianamics = Dianamics || {};
	Dianamics.HappynatorGrid = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.HappynatorGrid;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}