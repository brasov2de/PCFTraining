/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    happyProperty: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    colorType: ComponentFramework.PropertyTypes.EnumProperty<"Text" | "Border">;
}
export interface IOutputs {
    happyProperty?: boolean;
}
