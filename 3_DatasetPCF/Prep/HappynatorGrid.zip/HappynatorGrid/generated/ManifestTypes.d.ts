/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    OptionsYellow: ComponentFramework.PropertyTypes.MultiSelectOptionSetProperty;
    dataset: ComponentFramework.PropertyTypes.DataSet;
}
export interface IOutputs {
}
