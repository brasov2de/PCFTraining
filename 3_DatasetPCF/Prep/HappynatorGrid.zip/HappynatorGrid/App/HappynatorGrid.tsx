import * as React from "react";
import { DetailsList } from "@fluentui/react/lib/DetailsList";


type DataSet = ComponentFramework.PropertyTypes.DataSet;

export interface IHappynatorAppProps {
    dataset : DataSet;
}

export const HappynatorApp = ({
    dataset
}: IHappynatorAppProps) : JSX.Element => {

    const columns = dataset.columns.sort((column1, column2) => column1.order - column2.order).map((column) => {
        return {
           name : column.displayName,
           fieldName : column.name,
           minWidth : column.visualSizeFactor, 
           key: column.name 
        }
    } );

    const [items, setItems] = React.useState<any[]>([]);
    React.useEffect(() => {
        setItems(dataset.sortedRecordIds.slice(0, Math.min(dataset.sortedRecordIds.length, dataset.paging.totalResultCount)).map((id) => {                
            const entityIn = dataset.records[id];
            const attributes = dataset.columns.map((column) => {                     
                    return  { [column.name] :     column.alias === "happyProperty" 
                        ? entityIn.getValue(column.name) ==="1" ? "☺" : "☹" 
                        : entityIn.getFormattedValue(column.name)
                    }
                         
            });
            return Object.assign({
                    key: entityIn.getRecordId(),
                    raw : entityIn
                },
                ...attributes);
            }));    
    }, [dataset]);  


    return (<DetailsList            
        columns={columns}
        items={items}
        setKey="set"
        >
        </DetailsList>
        
    );
};